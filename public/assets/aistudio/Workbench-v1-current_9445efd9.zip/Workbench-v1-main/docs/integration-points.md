# Integration Points

This document records the application’s integration points.
Ledger requires a 'dossier' store in db.js to persist commitments and deltas.
Decision: Add a dedicated 'dossier' store, rather than overloading 'sessions'.
